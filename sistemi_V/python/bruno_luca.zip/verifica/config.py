

SERVER_IP = "127.0.0.1"
SERVER_PORT = 8500
DB_NAME = "operations.db"

